<!DOCTYPE html>
<html>
<head>
	<title>My Form</title>
	<style type="text/css">
		body {
			background-color: #A23E48; 
			color: #E8F0F7;
			padding: 24px;
		}
		ul {
			list-style-type: none;
		}
		li {
			padding: 4px;
		}
		input {
			margin-left: 8px;
		}
		table, th, td {
			border-collapse: collapse;
			border: 2px solid #E8F0F7;
			padding: 4px;
		}
	</style>
</head>
<body>
<center>
<?php 
	switch ($_GET['q']) {
		case 'ae':
			echo "<h1>Hi welcome to the form for people who know Todd! (That's me!)</h1><h2 style='color:red;'>Error! that username already existes please pick a new one or select update!</h2>";
			break;
		case 'ip':
			echo "<h1>Hi welcome to the form for people who know Todd! (That's me!)</h1><h2 style='color:red;'>Error! Incorrect Password!</h2>";
			break;
		case 'ss':
			echo "<h1>Hi welcome to the form for people who know Todd! (That's me!)</h1><h2 style='color:green;'>Sucess! Entry creates/updated!</h2>";
			break;
		default:
			echo "<h1>Hi welcome to the form for people who know Todd! (That's me!)</h1><h2>Please fill out the info below!</h2>";
			break;
	}
 ?>
 <hr>
<div class="input">
	<form  class="myform" action="mysubmit.php" method="post">	
	<ul>
		<li>would you like to Update? or Create a new relation?</li>
		<li>please note you will need the proper username and password to update your record</li> 
		<li>
			<input required type="radio" name="switch" value="true">Update
			<input required type="radio" name="switch" value="false" checked>Create
		</li>
	</ul>
	<ul>
		<li>First Name<input required type="text" name="firstName"></li>
		<li>Last Name<input required type="text" name="lastName"></li>
		<li>Phone Number<input required type="tel" name="phoneNumber"></li>
		<li>Address<input required type="text" name="address"></li>
		<li>City<input required type="text" name="city"></li>
		<li>State<input required type="text" name="state"></li>
		<li>Zip<input required type="text" name="zip"></li>
		<li>Birthdate<input required type="date" name="birthdate"></li>
		<li>Username<input required type="username" name="username"></li>
		<li>Password<input required type="password" name="password"></li>
		<li>Gender
			<input required type="radio" name="gender" value="M"> Male
			<input required type="radio" name="gender" value="F"> Female
		</li>
		<li>Relation to Me!
			<select name="relation">
			  <option value="family">Family</option>
			  <option value="friend">Friend</option>
			  <option value="m8">m8</option>
			  <option value="thatoneguy">That One Guy</option>
			</select>
		</li>
	</ul>
	<input type="submit" name="submit">
	</form>
	<hr>
	<form  class="search" action="myform.php" method="post">
		<h3>Search via First or Last name here!</h3>
		<ul>
			<li>Search by First Name: <input type="search" name="searchFirst"></li>
			<li>search by Last Name: <input type="search" name="searchLast"></li>
		</ul>
		<input type="submit" name="search" value="Search">
	</form>
</div>
<div class="output">
<br>
	<table>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Phone Number</th>
			<th>Address</th>
			<th>City</th>
			<th>State</th>
			<th>Zip</th>
			<th>Birthdate</th>
			<th>Username</th>
			<th>Password</th>
			<th>Gender</th>
			<th>Relation to Me</th>
		</tr>
<?php 
	// require_once('php/db_functions.php');
	// for ($i=0; $i < $results->num_rows; $i++) { 
	// 	$row=(mysqli_fetch_array($results));
	// 	echo "<tr><td>" . $row["firstName"] . "</td><td>" . $row["lastName"] . "</td><td>" . $row["phoneNumber"] . "</td><td>" . $row["address"] . "</td><td>" . $row["city"] . "</td><td>" . $row["state"] . "</td><td>" . $row["zip"] . "</td><td>" . $row["birthdate"] . "</td><td>" . $row["username"] . "</td><td> ********** </td><td>" . $row["gender"] . "</td><td>" . $row["relation"] . "</td></tr>";
	// } 
	
	require_once('php/db_functions.php');
	$searchFirst = $_POST['searchFirst'];
	$searchLast = $_POST['searchLast'];
	// echo "First: $searchFirst Last: $searchLast querry:";
	if (isset($searchFirst) && isset($searchLast)) {
	$results = db_query("SELECT * FROM users WHERE firstName LIKE '%$searchFirst%' AND lastName LIKE'%$searchLast%'");
	} else {
	$results = db_query("SELECT * FROM users");	
	}
	for ($i=0; $i < $results->num_rows; $i++) { 
		$row=(mysqli_fetch_array($results));
		echo "<tr><td>" . $row["firstName"] . "</td><td>" . $row["lastName"] . "</td><td>" . $row["phoneNumber"] . "</td><td>" . $row["address"] . "</td><td>" . $row["city"] . "</td><td>" . $row["state"] . "</td><td>" . $row["zip"] . "</td><td>" . $row["birthdate"] . "</td><td>" . $row["username"] . "</td><td> ********** </td><td>" . $row["gender"] . "</td><td>" . $row["relation"] . "</td></tr>";
	}
?>
	</table>
</div>
</center>
</body>
<script type="text/javascript">
	var searchFirst = "<?php echo "$searchFirst"; ?>"
	var searchLast = "<?php echo "$searchLast"; ?>"
	document.querySelector("input[name='searchFirst']").value = searchFirst;
	document.querySelector("input[name='searchLast']").value = searchLast;
</script>
</html>